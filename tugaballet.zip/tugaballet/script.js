$(function () {
    $(".menu").click(function () {
        $(this).toggleClass('active');//メニュー（ハンバーガーメニュー）のボタンを×にするために入れる
        $(".nav").toggleClass('open');//ナビゲーションの出し入れに使う。
    });
});